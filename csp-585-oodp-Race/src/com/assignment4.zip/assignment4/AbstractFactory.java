package com.assignment4;

public abstract class AbstractFactory {
	abstract Name getName(String color);
	abstract Shape getShape(String shape) ;
}
