package com.assignment4;

public class NameEllipse implements Name{

	public String getName(){

		return "Ellipse";
	}
}
