package com.assignment4;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RaceMain {

	private List<Shape> shapeList = new ArrayList<>();
	private static List<String> nameList = new ArrayList<>();

	public List<Shape> getShapesList() {
		return shapeList;
	}

	public static void main(String[] args) throws IOException {

		RaceMain raceMain = new RaceMain();

		// get shape factory
		AbstractFactory shapeFactory = FactoryProducer.getFactory("Shape");

		Shape shape1 = shapeFactory.getShape("Ellipse");
		Shape shape2 = shapeFactory.getShape("Goofy");
		Shape shape3 = shapeFactory.getShape("SpongeBob");
		Shape shape4 = shapeFactory.getShape("Minny");
		Shape shape5 = shapeFactory.getShape("Mickey");
		Shape shape6 = shapeFactory.getShape("Homer");
		
		// get name factory
		AbstractFactory colorFactory = FactoryProducer.getFactory("Name");

		Name name1 = colorFactory.getName("Ellipse");
		Name name2 = colorFactory.getName("Goofy");
		Name name3 = colorFactory.getName("SpongeBob");
		Name name4 = colorFactory.getName("Minny");
		Name name5 = colorFactory.getName("Mickey");
		Name name6 = colorFactory.getName("Homer");

		nameList.add(name1.getName());
		nameList.add(name2.getName());
		nameList.add(name3.getName());
		nameList.add(name4.getName());
		nameList.add(name5.getName());
		nameList.add(name6.getName());

		// -----------------------------------------------------------------

		raceMain.addRacingCartoon(shape1);
		raceMain.addRacingCartoon(shape2);
		raceMain.addRacingCartoon(shape3);
		raceMain.addRacingCartoon(shape4);
		raceMain.addRacingCartoon(shape5);
		raceMain.addRacingCartoon(shape6);

		DashboardFrame obj = new DashboardFrame(raceMain, nameList);

	}

	public void addRacingCartoon(Shape obj) {
		shapeList.add(obj);
	}
}
