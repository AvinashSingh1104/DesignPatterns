package com.assignment4;

public class ShapeFactory extends AbstractFactory {
	
	   @Override
	   public Shape getShape(String shapeType){
	   
	      if(shapeType == null){
	         return null;
	      }		
	      
		if (shapeType.equalsIgnoreCase("Ellipse")) {
			return new Ellipse("Ellipse");

		} else if (shapeType.equalsIgnoreCase("Goofy")) {
			return new Goofy("Goofy");

		} else if (shapeType.equalsIgnoreCase("SpongeBob")) {
			return new SpongeBob("SpongeBob");

		} else if (shapeType.equalsIgnoreCase("Minny")) {
			return new Minny("Minny");

		} else if (shapeType.equalsIgnoreCase("Mickey")) {
			return new Mickey("Mickey");

		} else if (shapeType.equalsIgnoreCase("Homer")) {
			return new Homer("Homer");

		}

		return null;
	   }
	   
	   @Override
	   Name getName(String color) {
	      return null;
	   }
	}